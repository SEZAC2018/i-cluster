#!/bin/sh

set -e

wget https://releases.linaro.org/components/toolchain/binaries/5.1-2015.08/armeb-linux-gnueabihf/gcc-linaro-5.1-2015.08-x86_64_armeb-linux-gnueabihf.tar.xz
tar xJf  gcc-linaro-5.1-2015.08-x86_64_armeb-linux-gnueabihf.tar.xz
