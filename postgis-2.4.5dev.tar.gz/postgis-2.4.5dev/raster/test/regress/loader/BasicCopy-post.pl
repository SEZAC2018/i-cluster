unlink "loader/BasicCopy.tif";
